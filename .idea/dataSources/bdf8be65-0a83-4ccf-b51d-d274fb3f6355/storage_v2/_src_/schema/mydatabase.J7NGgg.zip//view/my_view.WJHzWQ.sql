create definer = root@localhost view my_view as
select `mydatabase`.`orders`.`id` AS `id`, `mydatabase`.`orders`.`product` AS `product`
from `mydatabase`.`orders`;

